package com.exam.login.model

import android.graphics.drawable.Drawable

data class Shoe(
    val img: String,
    val saleLevel: String,
    val name: String,
    val subname: String,
    val pirce: String,
    val desc : String

)


