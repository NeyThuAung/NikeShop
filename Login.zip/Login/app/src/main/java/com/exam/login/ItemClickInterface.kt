package com.exam.login

interface ItemClickInterface {
    fun onItemClick(position : Int)
}